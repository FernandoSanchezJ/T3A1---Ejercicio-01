/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
import java.util.Scanner;


/**
 *
 * @author USER
 */
public class T3A1 {

    public static void main(String[] args){
        procesar();
    }
    public static void procesar(){
        Scanner scanner = new Scanner (System.in);
        Calificaciones calificaciones = new Calificaciones();
        
        System.out.println("Nombre:");
        String nombre = scanner.nextLine();
        calificaciones.setNombre(nombre);
        
        System.out.println("Apellido Paterno:");
        String apellidoPaterno = scanner.nextLine();
        calificaciones.setApellidoPaterno(apellidoPaterno);
        
        System.out.println("Apellido Materno:");
        String apellidoMaterno = scanner.nextLine();
        calificaciones.setApellidoMaterno(apellidoMaterno);
        
        System.out.println("Grupo:");
        String grupo = scanner.nextLine();
        calificaciones.setGrupo(grupo);
        
        System.out.println("Carrera:");
        String carrera = scanner.nextLine();
        calificaciones.setCarrera(carrera);
        
        System.out.println("Nombre de Asignatura No1: ");
        String nombreAsignatura = scanner.nextLine();
        calificaciones.setNombreAsignatura1(nombreAsignatura);
        
        System.out.println("Nombre de la asignatura No2: ");
        String nombreAsignatira2 = scanner.nextLine();
        calificaciones.setNombreAsignatura2(nombreAsignatira2);
                
        System.out.print("Calificación No1: ");
        int calificacion = scanner.nextInt();
        calificaciones.setCalificacion1(calificacion);

        System.out.print("Calificación No2: ");
        int calificacion2 = scanner.nextInt();
        calificaciones.setCalificacion2(calificacion);
        
        System.out.println("Su promedio general es de: " + (calificacion + calificacion2)/2);
        double Promedio = (calificacion + calificacion2)/2;
        calificaciones.setPromedio(Promedio);
        
        System.out.println(calificaciones.toString());
    }
}
